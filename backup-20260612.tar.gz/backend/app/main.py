from fastapi import FastAPI, HTTPException
from sqlalchemy import text

from app.database.db import engine
from app.schemas.stock import StockCreate

from app.services.upstox import (
    get_profile,
    search_instrument,
    scan_stock
)

from app.services.telegram import send_telegram_message

app = FastAPI(
    title="My Stock Scanner",
    version="1.0.0"
)


@app.get("/")
def root():
    return {
        "status": "running",
        "app": "my-stock-scanner"
    }


@app.get("/health")
def health():
    return {"healthy": True}


@app.get("/stocks")
def get_stocks():
    with engine.connect() as conn:
        result = conn.execute(
            text("""
                SELECT id, symbol, exchange, instrument_key
                FROM stocks
                ORDER BY symbol
            """)
        )

        return [
            {
                "id": row.id,
                "symbol": row.symbol,
                "exchange": row.exchange,
                "instrument_key": row.instrument_key
            }
            for row in result
        ]


@app.get("/watchlists")
def get_watchlists():

    with engine.connect() as conn:

        result = conn.execute(
            text("""
                SELECT
                    id,
                    name,
                    created_at
                FROM watchlists
                ORDER BY name
            """)
        )

        return [
            {
                "id": row.id,
                "name": row.name,
                "created_at": row.created_at
            }
            for row in result
        ]


@app.get("/watchlists/{name}")
def get_watchlist(name: str):

    with engine.connect() as conn:

        rows = conn.execute(
            text("""
                SELECT
                    s.id,
                    s.symbol,
                    s.exchange,
                    s.instrument_key
                FROM watchlist_stocks ws
                JOIN watchlists w
                    ON ws.watchlist_id = w.id
                JOIN stocks s
                    ON ws.stock_id = s.id
                WHERE UPPER(w.name) = UPPER(:name)
                ORDER BY s.symbol
            """),
            {"name": name}
        ).fetchall()

    if not rows:
        raise HTTPException(
            status_code=404,
            detail=f"Watchlist '{name}' not found or empty"
        )

    return [
        {
            "id": row.id,
            "symbol": row.symbol,
            "exchange": row.exchange,
            "instrument_key": row.instrument_key
        }
        for row in rows
    ]


@app.get("/watchlists/{name}/scanner")
def scan_watchlist(name: str):

    with engine.connect() as conn:

        rows = conn.execute(
            text("""
                SELECT
                    s.symbol,
                    s.instrument_key
                FROM watchlist_stocks ws
                JOIN watchlists w
                    ON ws.watchlist_id = w.id
                JOIN stocks s
                    ON ws.stock_id = s.id
                WHERE
                    UPPER(w.name) = UPPER(:name)
                    AND s.active = TRUE
                ORDER BY s.symbol
            """),
            {"name": name}
        ).fetchall()

    if not rows:
        raise HTTPException(
            status_code=404,
            detail=f"Watchlist '{name}' not found or empty"
        )

    results = []

    for stock in rows:

        if not stock.instrument_key:
            continue

        try:

            results.append(
                scan_stock(
                    stock.symbol,
                    stock.instrument_key
                )
            )

        except Exception as e:

            results.append(
                {
                    "symbol": stock.symbol,
                    "error": str(e)
                }
            )

    return results


@app.post("/stocks")
def create_stock(stock: StockCreate):
    with engine.connect() as conn:

        conn.execute(
            text("""
                INSERT INTO stocks(symbol, exchange)
                VALUES (:symbol, :exchange)
            """),
            {
                "symbol": stock.symbol.upper(),
                "exchange": stock.exchange.upper()
            }
        )

        conn.commit()

    return {
        "message": "Stock added",
        "symbol": stock.symbol.upper()
    }


@app.delete("/stocks/{stock_id}")
def delete_stock(stock_id: int):

    with engine.connect() as conn:

        conn.execute(
            text("""
                DELETE FROM stocks
                WHERE id = :id
            """),
            {"id": stock_id}
        )

        conn.commit()

    return {
        "message": "Stock deleted",
        "id": stock_id
    }


@app.get("/upstox/profile")
def upstox_profile():
    return get_profile()


@app.get("/search/{symbol}")
def search(symbol: str):
    return search_instrument(symbol)


@app.get("/scanner")
def scanner():

    with engine.connect() as conn:

        stocks = conn.execute(
            text("""
                SELECT symbol, instrument_key
                FROM stocks
                WHERE active = TRUE
                ORDER BY symbol
            """)
        ).fetchall()

    results = []

    for stock in stocks:

        if not stock.instrument_key:
            continue

        try:

            results.append(
                scan_stock(
                    stock.symbol,
                    stock.instrument_key
                )
            )

        except Exception as e:

            results.append(
                {
                    "symbol": stock.symbol,
                    "error": str(e)
                }
            )

    return results


@app.get("/scanner/run")
def scanner_run():

    with engine.connect() as conn:

        stocks = conn.execute(
            text("""
                SELECT symbol, instrument_key
                FROM stocks
                WHERE active = TRUE
                ORDER BY symbol
            """)
        ).fetchall()

        results = []
        alert_stocks = []

        for stock in stocks:

            if not stock.instrument_key:
                continue

            try:

                result = scan_stock(
                    stock.symbol,
                    stock.instrument_key
                )

                conn.execute(
                    text("""
                        INSERT INTO scanner_results
                        (
                            symbol,
                            signal,
                            latest_close,
                            latest_volume,
                            avg_volume20,
                            sma9,
                            sma21,
                            rsi14,
                            breakout
                        )
                        VALUES
                        (
                            :symbol,
                            :signal,
                            :latest_close,
                            :latest_volume,
                            :avg_volume20,
                            :sma9,
                            :sma21,
                            :rsi14,
                            :breakout
                        )
                    """),
                    result
                )

                if result["signal"] in [
                    "STRONG BUY",
                    "RSI_BREAKOUT"
                ]:
                    alert_stocks.append(result)

                results.append(result)

            except Exception as e:

                results.append(
                    {
                        "symbol": stock.symbol,
                        "error": str(e)
                    }
                )

        conn.commit()

    if alert_stocks:

        message = "📈 My Stock Scanner\n\n"

        for stock in alert_stocks:

            message += (
                f"{stock['symbol']}\n"
                f"Signal: {stock['signal']}\n"
                f"Close: {stock['latest_close']}\n"
                f"RSI14: {stock['rsi14']}\n"
                f"Breakout: {stock['breakout']}\n\n"
            )

        send_telegram_message(message)

    return results
