import os
import requests
import pandas as pd

UPSTOX_ACCESS_TOKEN = os.getenv("UPSTOX_ACCESS_TOKEN")


def get_profile():
    response = requests.get(
        "https://api.upstox.com/v2/user/profile",
        headers={
            "Authorization": f"Bearer {UPSTOX_ACCESS_TOKEN}",
            "Accept": "application/json"
        }
    )
    return response.json()


def search_instrument(query):
    return {"query": query}


def calculate_rsi(series, period=14):
    delta = series.diff()

    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)

    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()

    rs = avg_gain / avg_loss

    return 100 - (100 / (1 + rs))


def get_candles(instrument_key):

    response = requests.get(
        f"https://api.upstox.com/v2/historical-candle/{instrument_key}/day/2025-06-12/2025-01-01",
        headers={
            "Authorization": f"Bearer {UPSTOX_ACCESS_TOKEN}",
            "Accept": "application/json"
        }
    )

    data = response.json()

    candles = data["data"]["candles"]

    rows = []

    for candle in reversed(candles):
        rows.append(
            {
                "date": candle[0],
                "open": candle[1],
                "high": candle[2],
                "low": candle[3],
                "close": candle[4],
                "volume": candle[5]
            }
        )

    df = pd.DataFrame(rows)

    df["sma9"] = df["close"].rolling(9).mean()
    df["sma21"] = df["close"].rolling(21).mean()
    df["avg_volume20"] = df["volume"].rolling(20).mean()
    df["rsi14"] = calculate_rsi(df["close"])

    latest = df.iloc[-1]

    previous_20_high = df["high"].iloc[-21:-1].max()

    breakout = latest["close"] > previous_20_high

    signal = "BUY"

    if (
        latest["sma9"] > latest["sma21"]
        and latest["volume"] > latest["avg_volume20"]
    ):
        signal = "STRONG BUY"

    if (
        latest["rsi14"] > 60
        and breakout
        and latest["volume"] > latest["avg_volume20"]
    ):
        signal = "RSI_BREAKOUT"

    return {
        "latest_close": round(float(latest["close"]), 2),
        "latest_volume": int(latest["volume"]),
        "avg_volume20": int(latest["avg_volume20"]),
        "sma9": round(float(latest["sma9"]), 2),
        "sma21": round(float(latest["sma21"]), 2),
        "rsi14": round(float(latest["rsi14"]), 2),
        "breakout": bool(breakout),
        "signal": signal
    }


def scan_stock(symbol, instrument_key):
    data = get_candles(instrument_key)

    return {
        "symbol": symbol,
        **data
    }

